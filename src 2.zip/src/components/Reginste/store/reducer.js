export  default (state={name:"infer"},action)=>{
    switch(action.type){
        default:
            return state
    }
}